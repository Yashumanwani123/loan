{
    'name': 'Loan Management',
    'version': '1.0',
    'summary': 'Manage customer loans, types, rules, and calculations',
    'depends': ['base', 'account'], 
    'data': [
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/action.xml',
        'views/menu.xml',
        'views/loan_views.xml',
        'views/loan_type.xml',
        'views/loan_rule.xml',
        'wizard/decline.xml',
        'reports/action_repo.xml',
        'reports/loan_pdf.xml',
        'security/security.xml',
        'views/invoice.xml'
    ],
    'installable': True,
    'application': True,
}

