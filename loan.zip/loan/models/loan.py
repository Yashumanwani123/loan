from odoo import models, fields, api
from dateutil.relativedelta import relativedelta

class Loan(models.Model):
    _name = 'loan.management'
    _description = 'Loan Management'
    _rec_name = 'loan_type_id'
    _inherit = ['mail.thread','mail.activity.mixin']

    ref=fields.Char(string="reference", default=lambda self:'NEW')
    customer_id = fields.Many2one('res.partner', string='Customer', required=True)
    loan_amount = fields.Monetary(string='Loan Amount (₹)', required=True,currency_field='currency_id',default=0.0)
    down_payment = fields.Monetary(string='Down Payment', required=True, currency_field='currency_id',default=0.0)
    effective_loan_amount = fields.Monetary(string='Effective Loan Amount', compute='_compute_effective_loan_amount', store=True, default=0.0)
    tenure = fields.Integer(string='Tenure (Months)', required=True)
    description =  fields.Char(string = "Description")
    interest = fields.Float(string='Interest p.a(%)', required=True)
    salary = fields.Monetary(string='Salary (Monthly ₹)', required=True,currency_field='currency_id',default=0.0)
    job_type = fields.Selection([
        ('self_employed', 'Self-Employed'),
        ('unemployed', 'Unemployeed'),
        ('gov_employee', 'Government Employee'),
        ('privet_employee', 'Private Sector Employee'),
        ('business_owner', 'Business owner'),
        ('student', 'Student'),
        ('pensioner', 'Pensioner'),
    ], string='Job Type', required=True)
    loan_type_id = fields.Many2one('loan.type', string='Loan Type', required=True)
    emi_amount = fields.Monetary(string='EMI Amount (₹)', compute='_compute_emi_amount', store=True, currency_field='currency_id', default=0.0)
    document_ids = fields.One2many('loan.management.document', 'loan_id', string='Required Documents')
    terms_conditions = fields.Html(string='Terms and Conditions', compute='depend_terms_condition')
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.ref('base.INR').id)
    status = fields.Selection([
        ('new', 'New'),
        ('draft', 'Draft'),
        ('confirm', 'Confirmed'),           
        ('decline', 'Declined'),
        ('approve', 'Approved'),
        ('disburse', 'Disbursed'),
        ('settled', 'Settled'),
        ('cancel', 'Cancel')
    ], string='Status', readonly=True, index=True, copy=False, default='new',tracking=True)
    payment_type = fields.Selection([
        ('cash', 'Cash'),
        ('bank', 'Bank Transfer'),
        ('cheque', 'Cheque'),
        ('credit_card', 'Credit Card'),
        ('debit_card', 'Debit Card'),
        ('online', 'Online Payment Gateway UPI'),
        ('other', 'Other')
    ], string='Payment Type', required=True)
    
    decline_reason = fields.Text(string='Decline Reason')
    emi_ids = fields.Many2many('loan.management.emi', string='EMI Details')
    start_date = fields.Date(string='Apply Date', required=True,default=lambda self: fields.Date.today())
    confirm_date = fields.Date(string='Confirmation Date')
    approve_date = fields.Date(string='Approve Date')
    close_date = fields.Date(string='Close Date', compute='_compute_close_date', store=True)
    
    acc_number = fields.Char(string="Bank Account Number", compute='_compute_bank_details', store=True)
    bank_name = fields.Char(string="Bank Name", compute='_compute_bank_details', store=True)

    total_principal_paid = fields.Monetary(string='Total Principal Paid', compute='_compute_total_sums', currency_field='currency_id')
    total_interest_charged = fields.Monetary(string='Total Interest Charged', compute='_compute_total_sums', currency_field='currency_id')
    total_late_fee = fields.Monetary(string='Total Late Fee', compute='_compute_total_sums', currency_field='currency_id')
    total_payment = fields.Monetary(string='Total Payment', compute='_compute_total_sums', currency_field='currency_id')
    
    payment_term_id = fields.Many2one('account.payment.term', string='Payment Term',default=lambda self: self.env['account.payment.term'].search([('name', '=', '30 Days')], limit=1).id)

    # add for bank Details
    @api.depends('customer_id')
    def _compute_bank_details(self):
        for loan in self:
            if loan.customer_id:
                bank_account = self.env['res.partner.bank'].search([('partner_id', '=', loan.customer_id.id)], limit=1)
                loan.acc_number = bank_account.acc_number
                loan.bank_name = bank_account.bank_id.name
            else:
                loan.acc_number = False
                loan.bank_name = False

    # Status Actions
    def action_confirm(self):
        self.write({
            'status': 'confirm',
            'confirm_date': fields.Date.today(),
        })

    def action_cancel(self):
        self.write({'status': 'cancel'})
            
    def action_draft(self):
        self.write({'status': 'new'})
    
    def action_approve(self):
        self.write({
            'status': 'approve',
            'approve_date': fields.Date.today(),
        })

    def action_decline(self):
        return {
            'name': 'Decline Loan',
            'type': 'ir.actions.act_window',
            'res_model': 'loan.decline.wizard',
            'view_mode': 'form',
            'target': 'new',
        }

    def action_disburse(self):
        self.write({'status': 'disburse'})
        self._generate_emi_schedule()   
        
    def action_settle(self):
        self.write({'status': 'settled'})
        

    # EMI Calculation
    @api.depends('effective_loan_amount', 'tenure', 'interest')
    def _compute_emi_amount(self):
        for loan in self:
            if loan.tenure and loan.interest:
                r = loan.interest / 12 / 100
                emi = loan.effective_loan_amount * r * (1 + r) ** loan.tenure / ((1 + r) ** loan.tenure - 1)
                loan.emi_amount = emi
                
    #  for sequence Number 
    @api.model_create_multi
    def create(self, vals_list):
        for i in vals_list:
                i['ref']=self.env['ir.sequence'].next_by_code('loan.management')  
        return super().create(vals_list)
    
    
    
    # Dynamic Document show as per loan Type
    @api.onchange('loan_type_id')
    def _onchange_loan_type_id(self):
        if self.loan_type_id:
            document_lines = [(5, 0, 0)]  
            for doc in self.loan_type_id.document_ids:
                document_lines.append((0, 0, {
                    'name': doc.name,
                }))
                
            self.document_ids = document_lines
   
        
        
    # Down Payment Deduction     
    @api.depends('loan_amount', 'down_payment')
    def _compute_effective_loan_amount(self):
        for loan in self:
            if loan.loan_amount:
                loan.effective_loan_amount = loan.loan_amount - loan.down_payment
          
    
    # for extend field in module from loan types  like intrest, tenure,    
    @api.onchange('loan_type_id')
    def _extend_loan_details(self):
        for loan in self:
            loan.interest = loan.loan_type_id.interest
            loan.tenure = loan.loan_type_id.max_emi_tenure
    
    # extend t&c 
    @api.depends('loan_type_id')
    def depend_terms_condition(self):
        for loan in self:
            loan.terms_conditions = loan.loan_type_id.terms_conditions
            

    # Auto Calculate Closing Date  As Per Tenure in months
    @api.depends('confirm_date', 'tenure')
    def _compute_close_date(self):
        for loan in self:
            if loan.confirm_date and loan.tenure:
                loan.close_date = loan.confirm_date + relativedelta(months=loan.tenure)
            else:
                loan.close_date = False
                
                
   
    # Loan Rules by constraints
    @api.constrains('loan_amount', 'salary', 'tenure')
    def _check_loan_rules(self):
        for loan in self:
            rules = self.env['loan.rules'].search([
                ('loan_type_id', '=', loan.loan_type_id.id)
            ])
            
            for rule in rules:
                if loan.loan_amount > rule.max_amount:
                    raise models.ValidationError(
                        f"Loan amount exceeds the maximum limit for the selected loan type ({rule.max_amount})"
                    )
                if loan.salary < rule.min_salary:
                    raise models.ValidationError(
                        "Salary does not meet the minimum required salary for the selected loan type"
                    )
                if loan.tenure > rule.tenure_limit:
                    raise models.ValidationError(
                        f"Tenure exceeds the maximum limit for the selected loan type ({rule.tenure_limit} months)"
                    )
                    
     
    # Generate Emi Statement Report
    def _generate_emi_schedule(self):
        self.emi_ids.unlink()
        
        if self.tenure and self.effective_loan_amount and self.confirm_date:
            emi_amount = self.emi_amount
            remaining_principal = self.effective_loan_amount
            confirm_date = self.confirm_date

            emi_lines = []
            for i in range(1, self.tenure + 1):
                interest_component = remaining_principal * self.interest / 12 / 100
                principal_component = emi_amount - interest_component
                remaining_principal -= principal_component

                emi_lines.append((0, 0, {
                    'sequence': i,
                    'due_date': confirm_date + relativedelta(months=i),
                    'principal_paid': principal_component,
                    'interest_charged': interest_component,
                    'total_payment': emi_amount,
                    'balance': remaining_principal,
                    'payment_date': False,
                    'late_fee': 0.0, 
                }))
            self.emi_ids = emi_lines
   
   
    @api.depends('emi_ids')
    def _compute_total_sums(self):
        for record in self:
            record.total_principal_paid = sum(emi.principal_paid for emi in record.emi_ids)
            record.total_interest_charged = sum(emi.interest_charged for emi in record.emi_ids)
            record.total_late_fee = sum(emi.late_fee for emi in record.emi_ids)
            record.total_payment = sum(emi.total_payment for emi in record.emi_ids)
            
# For Needed Documents in One2many 
class LoanManagementDocument(models.Model):
    _name = 'loan.management.document'
    _description = 'Loan Management Document'

    name = fields.Char(string='Document Name', required=True)
    document = fields.Binary(string='Upload Document', required=False)
    loan_id = fields.Many2one('loan.management', string='Loan',readonly=True)


class LoanManagementEmi(models.Model):
    _name = 'loan.management.emi'
    _description = 'Loan EMI Schedule'


    sequence = fields.Integer(string='Sequence')
    due_date = fields.Date(string='Due Date')
    principal_paid = fields.Monetary(string='Principal Paid',currency_field='currency_id')  
    interest_charged = fields.Monetary(string='Interest Charged' ,currency_field='currency_id')  
    total_payment = fields.Monetary(string='Total Payment', compute='_compute_total_payment', store=True, currency_field='currency_id')  
    balance = fields.Monetary(string='Loan Balance' ,currency_field='currency_id') 
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.ref('base.INR').id)
 
    payment_date = fields.Date(string='Payment Date')
    late_fee = fields.Monetary(string='Late Fee', compute='_compute_late_fee', store=True, currency_field='currency_id',default=0.0)


    @api.depends('payment_date', 'due_date')
    def _compute_late_fee(self):
        for emi in self:
            if emi.payment_date and emi.due_date and emi.payment_date > emi.due_date:
                days_late = (emi.payment_date - emi.due_date).days
                emi.late_fee = days_late * 50
           
    @api.depends('principal_paid', 'interest_charged', 'late_fee')
    def _compute_total_payment(self):
        for emi in self:
            emi.total_payment = emi.principal_paid + emi.interest_charged + emi.late_fee
