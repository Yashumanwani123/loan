from odoo import models, fields, api

class AccountMove(models.Model):
    _inherit = 'account.move'
    
    loan_type_id = fields.Many2one('loan.management', string='Loan')
    emi_ids = fields.Many2many('loan.management.emi', string='EMI Schedule')
    
    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            loan = self.env['loan.management'].search([
                ('customer_id', '=', self.partner_id.id),
                ('status', 'in', ['approve', 'disburse',])
            ], limit=1, order='approve_date desc')

            if loan:
                self.loan_type_id = loan.id
                self.invoice_payment_term_id = loan.payment_term_id
                self.emi_ids = [(6, 0, loan.emi_ids.ids)]  
            else:
                self.loan_type_id = False
                self.emi_ids = False
                self.invoice_payment_term_id = False
