from odoo import models, fields

class LoanType(models.Model):
    _name = 'loan.type'
    _description = 'Loan Type'

    name = fields.Char(string='Loan Type', required=True)
    max_emi_tenure = fields.Integer(string='Maximum EMI Tenure (Months)')
    interest = fields.Float(string='Interest p.a(%)')
    eligibility_criteria_ids = fields.One2many('loan.eligibility.criteria', 'loan_type_id', string='Eligibility Criteria')
    terms_conditions = fields.Text(string='Terms and Conditions')  
    max_amount = fields.Float(string='Maximum Amount', store=True)
    document_ids = fields.Many2many('loan.type.document', string='Required Documents')
    
    
# for One2many
class LoanEligibilitfield_name(models.Model):
    _name = 'loan.eligibility.criteria'
    _description = 'Loan Eligibility Criteria'
    
    loan_type_id = fields.Many2one('loan.type', string='Loan Type', required=True)
    year_from = fields.Integer(string='Year From')
    year_to = fields.Integer(string='Year To')
    max_amount = fields.Float(string='Maximum Amount')
    

    
class LoanTypeDocument(models.Model):
    _name = 'loan.type.document'
    _description = 'Loan Type Document'

    name = fields.Char(string='Document Name', required=True)


    

    
    