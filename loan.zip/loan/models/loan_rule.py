from odoo import models, fields

class LoanRules(models.Model):
    _name = 'loan.rules'
    _description = 'Loan Rules'

    name = fields.Char(string='Rule Name', required=True)
    loan_type_id = fields.Many2one('loan.type', string='Loan Type', required=True)
    max_amount = fields.Float(string='Maximum Amount')
    min_salary = fields.Float(string='Minimum Salary')
    tenure_limit = fields.Integer(string='Tenure Limit (Months)')
    description = fields.Text(string='Description')


