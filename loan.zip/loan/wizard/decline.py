from odoo import models, fields, api

class LoanDeclineWizard(models.TransientModel):
    _name = 'loan.decline.wizard'
    _description = 'Loan Decline Wizard'

    decline_reason = fields.Text(string='Decline Reason', required=True)

    def action_decline_desc_save(self):
        loan_id = self.env.context.get('active_id')
        loan = self.env['loan.management'].browse(loan_id)
        
        loan.write({
            'description': self.decline_reason,
            'status': 'decline',
        })
        
        message = (
            f"Dear {loan.customer_id.name},\n\n"
            f"Your request for a loan has been declined due to the following reason:\n\n"
            f"Reason: {self.decline_reason}"
        )
        
        loan.message_post(body=message)